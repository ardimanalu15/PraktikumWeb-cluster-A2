# HOW TO USE
1. create database name "mahasiswa"
2. import tbl_users.sql and tbl_article.sql
